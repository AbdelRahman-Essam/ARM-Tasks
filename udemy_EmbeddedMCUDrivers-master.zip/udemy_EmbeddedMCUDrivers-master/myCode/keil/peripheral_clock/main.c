#include <stdint.h>
#include "stm32f446xx.h"

int main(void) {
	return 0;
}
